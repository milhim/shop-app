import 'package:flutter/material.dart';
import 'package:shop_app/constants.dart';

final theme = ThemeData(
  appBarTheme: AppBarTheme(
      color: Colors.white,
      elevation: 0,
      iconTheme: IconThemeData(color: Colors.black),
      centerTitle: true,
      titleTextStyle: TextStyle(color: Color(0xff888888), fontSize: 18)),
  visualDensity: VisualDensity.adaptivePlatformDensity,
  scaffoldBackgroundColor: Colors.white,
  fontFamily: 'open-sens',
  textTheme: TextTheme(
    bodyText1: TextStyle(color: kTextColor),
    bodyText2: TextStyle(color: kTextColor),
  ),
);
